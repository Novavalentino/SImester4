<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;
use CodeIgniter\Shield\Entities\User;

class AdminSeeder extends Seeder
{
    public function run()
    {
        $users = auth()->getProvider();

        // Buat user admin
        $user = new User([
            'username' => 'admin',
            'email'    => 'admin@gmail.com',
            'password' => 'admin123', // password minimal 8 karakter
        ]);
        $users->save($user);

        // Ambil ID user baru
        $userId = $users->getInsertID();

        // Masukkan ke tabel auth_groups_users secara manual
        $this->db->table('auth_groups_users')->insert([
            'user_id' => $userId,
            'group'   => 'admin',
        ]);
    }
}
