<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

service('auth')->routes($routes);

// Group Admin
$routes->group('admin', ['filter' => 'group:admin'], function($routes) {
    $routes->get('/', 'AdminController::index');
});

// Group User
$routes->group('user', ['filter' => 'group:user'], function($routes) {
    $routes->get('/', 'UserController::index');
});