<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
         // Jika sudah login, arahkan sesuai group
        if (auth()->loggedIn()) {
            if (auth()->user()->inGroup('admin')) {
                return redirect()->to('/admin');
            } elseif (auth()->user()->inGroup('user')) {
                return redirect()->to('/user');
            } else {
            // User tidak punya group yang valid
            return redirect()->to('/login')->with('error', 'Akses anda tidak valid.');
        }
    }

    return redirect()->to('/login');
    }
}
