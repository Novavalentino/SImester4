<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class UserController extends BaseController
{
    public function index()
    {
        return view('welcome_message');
    }
}
