<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Admin</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/admin.css') ?>">
</head>
<body>
    <div class="main">
        <h1>admin kuntul</h1>
        <a href="<?= url_to('logout') ?>">Logout</a>
    </div>
</body>
</html>