<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

use App\Models\PerpusModel;

class PerpusController extends BaseController
{
    protected $db_perpus;
    
    public function __construct() {
        $this->db_perpus = new PerpusModel();
    }

    public function index()
    {
        $getData = $this->db_perpus->findAll();
        $data = [
            'data'=>$getData
        ];
        

        if (!empty($data)){
            return view('layout/header').view('content/dataPerpus', $data).view('layout/footer');
        } else {
            echo "Data tidak ada";
        }
    }
}
