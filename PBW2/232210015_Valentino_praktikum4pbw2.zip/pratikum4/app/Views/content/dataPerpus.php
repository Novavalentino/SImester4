<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Perpustakaan</title>
</head>
<body>
    <section>
        <h1>List Buku</h1>
        <table border="1px">
            <tr>
                <th>Judul</th>
                <th>Pengarang</th>
                <th>Total Halaman</th>
                <th>Tahun Terbit</th>
            </tr>
            
            <?php foreach ($data as $d) : ?>
            <tr>
                <td><?= $d['judul']; ?></td>
                <td><?= $d['pengarang']; ?></td>
                <td><?= $d['halaman']; ?></td>
                <td><?= $d['tahunTerbit']; ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </section>
</body>
</html>