<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/perpus','PerpusController::index');
$routes->get('/mahasiswa','MahasiswaController::index', ['as' => 'mahasiswa']);

$routes->get('/mahasiswa/create','MahasiswaController::create');
$routes->post('/mahasiswa/store','MahasiswaController::store');

