<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Mahasiswa</title>
</head>
<body>
    <section>
        <h1>List Mahasiswa</h1>
        <a href="/mahasiswa/create">TAMBAH DATA</a>
        <table border="1px">
            <tr>
                <th>Npm</th>
                <th>Nama</th>
                <th>Alamat</th>
                <th>No. Telefon</th>
            </tr>
            
            <?php foreach ($data as $dm) : ?>
            <tr>
                <td><?= $dm['npm']; ?></td>
                <td><?= $dm['nama']; ?></td>
                <td><?= $dm['alamat']; ?></td>
                <td><?= $dm['nohp']; ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </section>
</body>
</html>