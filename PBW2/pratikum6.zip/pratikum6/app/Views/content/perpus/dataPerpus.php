<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Perpustakaan</title>
</head>
<body>
    <section>
        <h1>List Buku</h1>
        <a href="/buku/create">TAMBAH DATA</a>
        <table border="1px">
            <tr>
                <th>Judul</th>
                <th>Pengarang</th>
                <th>Total Halaman</th>
                <th>Tahun Terbit</th>
            </tr>
            
            <?php foreach ($data as $d) : ?>
            <tr>
                <td><?= $d['judul']; ?></td>
                <td><?= $d['pengarang']; ?></td>
                <td><?= $d['halaman']; ?></td>
                <td><?= $d['tahunTerbit']; ?></td>
                <td style="display: flex;"> 
                    <form action="<?= base_url('delete') . '/' . $d['id'] ?>" method="post"> 
                    <input type="hidden" name="_method" value="DELETE"> 
                        <button type="submit"> 
                            <a>Delete</a> 
                        </button> 
                    </form>
                </td> 
            </tr>
            <?php endforeach; ?>
        </table>
    </section>
</body>
</html>