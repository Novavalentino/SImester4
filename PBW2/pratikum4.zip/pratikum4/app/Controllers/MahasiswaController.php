<?php

namespace App\Controllers;

use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\RESTful\ResourceController;

use App\Models\MahasiswaModel;

class MahasiswaController extends ResourceController
{
    /**
     * Return an array of resource objects, themselves in array format.
     *
     * @return ResponseInterface
     */

    protected $db_mahasiswa;
    public function __construct() {
        $this->db_mahasiswa = new MahasiswaModel();
    }

    public function index()
    {
        $getData = $this->db_mahasiswa->findAll();
        $data= [
            'data'=>$getData
        ];
        if (!empty($data)){
            return view('layout/header').view('content/dataMahasiswa', $data).view('layout/footer');
        } else {
            echo "Data tidak ada";
        }
    }

    /**
     * Return the properties of a resource object.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function show($id = null)
    {
        //
    }

    /**
     * Return a new resource object, with default properties.
     *
     * @return ResponseInterface
     */
    public function new()
    {
        //
    }

    /**
     * Create a new resource object, from "posted" parameters.
     *
     * @return ResponseInterface
     */
    public function create()
    {
        return view('content/createMahasiswa');
    }


    public function store(){
        // helper form dan URL
        helper(['form', 'url']);
         
        //untuk validasi
        $validation = $this->validate([
            'npm' => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Masukkan NPM'
                ]
            ],
            'nama'    => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Masukkan Nama'
                ]
            ],
            'alamat'    => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Masukkan Alamat'
                ]
            ],
            'nohp'    => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Masukkan Nomor telefon'
                ]
            ],
        ]);

        if(!$validation) {

            //kembali ke view setelah di validasi jika ada error
            return view('content/createMahasiswa', [
                'validation' => $this->validator
            ]);

        } else {

             //model initialize
            $MahasiswaModel = new MahasiswaModel();
            
            //insert data into database
            $MahasiswaModel->insert([
                'npm'   => $this->request->getPost('npm'),
                'nama' => $this->request->getPost('nama'),
                'alamat' => $this->request->getPost('alamat'),
                'nohp' => $this->request->getPost('nohp'),
            ]);

            //flash message
            session()->setFlashdata('message', 'Data Berhasil Disimpan');

            return redirect()->route('mahasiswa');
        }
    }

    /**
     * Return the editable properties of a resource object.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function edit($id = null)
    {
        //
    }

    /**
     * Add or update a model resource, from "posted" properties.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function update($id = null)
    {
        //
    }

    /**
     * Delete the designated resource object from the model.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function delete($id = null)
    {
        //
    }
}
