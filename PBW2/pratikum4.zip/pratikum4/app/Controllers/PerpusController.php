<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

use App\Models\PerpusModel;

class PerpusController extends BaseController
{
    protected $db_perpus;
    
    public function __construct() {
        $this->db_perpus = new PerpusModel();
    }

    public function index()
    {
        $getData = $this->db_perpus->findAll();
        $data = [
            'data'=>$getData
        ];
        

        if (!empty($data)){
            return view('layout/header').view('content/dataPerpus', $data).view('layout/footer');
        } else {
            echo "Data tidak ada";
        }
    }

    public function create(){
        return view('content/perpus/createPerpustakaan');
    }

    public function store(){
        //menambahkan data
        $this->db_perpus ->insert([
            'judul'=>$this->request->getVar('judul'),
            'pengarang'=>$this->request->getVar('pengarang'),
            'halaman'=>$this->request->getVar('halaman'),
            'tahunTerbit'=>$this->request->getVar('tahunTerbit'),
        ]);

        return redirect()->to(base_url('/perpus'));
    }

    public function delete($id)
    {
        $this->db_perpus ->delete($id);
        return redirect()->to(base_url('/perpus'));
    }
}
