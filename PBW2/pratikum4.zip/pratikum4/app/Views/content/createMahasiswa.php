<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambahkan Data Mahasiswa</title>
</head>
<body>
    <div>
        <div class="validator">
            <?php if(isset($validation)) { ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo $validation->listErrors() ?>
                </div>
            <?php } ?>
        </div>

        <div class="formmahasiswa">
            <form action="/mahasiswa/store" method="POST">
                <div class="form-group">
                    <label>NPM</label>
                    <input type="number" class="form-control" name="npm" placeholder="Masukkan NPM">
                </div>
                <div class="form-group">
                    <label>NAMA</label>
                    <input type="text" class="form-control" name="nama" placeholder="Masukkan Nama">
                </div>
                <div class="form-group">
                    <label>ALAMAT</label>
                    <input type="text" class="form-control" name="alamat" placeholder="Masukkan Alamat">
                </div>
                <div class="form-group">
                    <label>NO. TELEFON</label>
                    <input type="number" class="form-control" name="nohp" placeholder="Masukkan Nomor Telefon">
                </div>

                <button type="submit">SIMPAN!!!!</button>
            </form>
        </div>
    </div>
</body>
</html>