<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambahkan Data Mahasiswa</title>
</head>
<body>
    <div>
        <div class="validator">
            <?php if(isset($validation)) { ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo $validation->listErrors() ?>
                </div>
            <?php } ?>
        </div>

        <div class="formmahasiswa">
            <form action="proses_add_data" method="post" style=" max-width: 400px; display:flex; flex-direction:column; gap:8px"> 
                <?= csrf_field() ?> 
                <div style="gap: 1px;  display: flex; flex-direction: column; max-width: 400px;"> 
                    <label for="judul">Judul</label> 
                    <input type="text" id="judul" name="judul"> 
                </div> 
                <div style="gap: 1px;  display: flex; flex-direction: column; max-width: 400px;"> 
                    <label for="pengarang">Pengarang</label> 
                    <input type="text" id="pengarang" name="pengarang"> 
                </div> 
                <div style="gap: 1px;  display: flex; flex-direction: column; max-width: 400px;"> 
                    <label for="total_halaman">Total Halaman</label> 
                    <input type="number" id="total_halaman" name="total_halaman"> 
                </div> 
                <div style="gap: 1px;  display: flex; flex-direction: column; max-width: 400px;"> 
                    <label for="tahun_terbit">Tahun Terbit</label> 
                    <input type="number" id="tahun_terbit" name="tahun_terbit"> 
                </div> 
                <button type="submit" style="max-width: 20%;">Submit</button> 
            </form> 
        </div>
    </div>
</body>
</html>