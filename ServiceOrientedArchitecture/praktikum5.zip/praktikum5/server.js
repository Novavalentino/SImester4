const app = require('./App');
const port = 3000;

app.listen(port, () => {
    console.log('server running on http://localhost:${PORT}');
});