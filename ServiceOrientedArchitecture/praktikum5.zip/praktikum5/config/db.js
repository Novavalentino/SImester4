const mysql = require('mysql2');

const pool = msqyl.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'praktikum_soa',
});

module.exports = pool.promise();