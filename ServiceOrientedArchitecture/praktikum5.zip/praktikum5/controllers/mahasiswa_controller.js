const db = require('../config/db');

const getAllMahasiswa = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM mahasiswa');
        res.json(rows);
    }catch (err) {
        res.status(500).json({error:err.message});
    }
};

const createMahasiswa = async (req,res) => {
    try {
        const {nama,npm,jurusan} = req.body;

        if(!nama || !npm || !jurusan){
            return res.status(400).json({error: 'semua field (nama,npm,jurusan) wajib diisi'});
        }

        const [result]= await db.querry(
            'INSERT INTO mahasiswa (nama,npm,jurusan) VALUES (?,?,?)', [nama,npm,jurusan] 
        );

        res.status(201).json({
            id: result.insertId,
            message: 'Mahasiswa berhadil ditambahkan'
        });
    }catch(err){
        if(err.code === 'ER_DUP_ENTRY'){
            return res.status(400).json({error: err.message});
        }
    }
};

const deleteMahasiswa = async (req,res)=>{
    try {
        const {id} = req.params;
        cons[result] = await db.query('DELETE FROM mahasiswa WHERE id = ?',[id]);

        if(!result.affectedRows === 0){
            return res.status(400).json({message: 'Mahasiswa tidak ditemukan'});
        }

        res.json({message: 'Mahasiswa berhasil dihapus'});
    }catch(err){
        res.statu(500).json({error: err.message});
    }
};

module.exports = {
    getAllMahasiswa,
    createMahasiswa,
    deleteMahasiswa
};