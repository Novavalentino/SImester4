const express = require('express');
const bodyParser = require('body-parser');
const mahasiswaRoutes = require('./routes/mahasiswa_routes');

const app = express();

app.use(bodyParser.json());
app.use('/api/mahasiswa', mahasiswaRoutes);

module.exports = app;