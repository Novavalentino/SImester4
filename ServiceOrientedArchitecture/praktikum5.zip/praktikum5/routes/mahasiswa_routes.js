const express = require('express');
const router = express.Router();
const {
    getAllMahasiswa,
    createMahasiswa,
    deleteMahasiswa
}=require('../controllers/mahasiswa_controller');

router.get('/', gerAllMahasiswa);
router.post('/', createMahasiswa);
router.delete('/:id', deleteMahasiswa);

module.exports = router;