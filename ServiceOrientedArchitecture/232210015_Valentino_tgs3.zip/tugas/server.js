const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

app.get('/', (req,res) =>{
    res.send('Tugas Perpustakaan');
});

let books = [
    {id:1, title: 'heriskuter', author: 'udin', year: "1998"},
    {id: 2, title: 'tarjan', author: 'disnep', year: "2001"},
    {id: 3, title: 'apenjer', author: 'danu', year: "1990"},
];

app.get('/api/books', (req,res) => {
    res.json(books);
});

app.get('/api/books/:id', (req,res) => {
    const book = books.find(s => s.id === parseInt(req.params.id));
    if(!book) return res.status(404).json({message: ' Buku tidak ditemukan'});
    res.json(book);
});

app.post('/api/books', (req,res) => {
    const {title,author,year} = req.body;
    if(!title, !author || !year) return res.status(400).json({message: 'judul tahun dan tahun buku harus diisi'});

    const newBook = {id:books.length + 1, title, author, year};
    books.push(newBook);
    res.status(201).json(newBook);
});

app.put('/api/books/:id', (req,res) => {
    const book = books.find(s => s.id === parseInt(req.params.id));
    if(!book) return res.status(404).json({message: 'Buku tidak ditemukan'});

    const {title,author,year} = req.body;
    if(title) book.title = title;
    if(author) book.author = author;
    if(year) book.year = year;

    res.json(book);
});

app.delete('/api/books/:id', (req,res) => {
    const index = books.findIndex(s => s.id === parseInt(req.params.id));
    if(!index === -1) return res.status(404).json({message: 'Buku tidak ditemukan'});

    books.splice(index,1);
    res.status(204).send();
});

app.listen(port, () => {
    console.log('Server berjalan di http:/localhost:${port}');
});